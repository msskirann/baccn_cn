import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-completion',
  templateUrl: './completion.component.html',
  styleUrls: ['./completion.component.css']
})
export class CompletionComponent implements OnInit {

  constructor() { }

  ngOnInit() {
    window.scrollTo(0, 0);
  }
  

  buttonIsDisabled:boolean = true;
  commentIsDisabled:boolean = true;
  allowSubmit :boolean=false;
  CommentsEntered() {
    this.allowSubmit = true;
    this.buttonIsDisabled = false;
    this.commentIsDisabled = false;
    } 

}
