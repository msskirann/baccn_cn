import { Component, OnInit, NgModule, Input, Output, EventEmitter } from '@angular/core';
import { MatButtonModule, MatInputModule, MatFormFieldModule } from '@angular/material';
import { FormControl, FormGroupDirective, NgForm, Validators, FormGroup, FormBuilder, DefaultValueAccessor } from '@angular/forms';
// import {ErrorStateMatcher} from '@angular/material/core';
import { IfObservable } from 'rxjs/observable/IfObservable';
import { RouterModule, Routes, Router } from '@angular/router';
import { BaccnService } from '../../../service/baccn.service';





@Component({
  selector: 'app-contact',
  templateUrl: './contact.component.html',
  styleUrls: ['./contact.component.css']
})

export class ContactComponent implements OnInit {
  @Output() isContactFormValid: EventEmitter<any> = new EventEmitter<any>();
  @Output() isBillingFormValid: EventEmitter<any> = new EventEmitter<any>();




  showhide: boolean;
  submitted: boolean;
  selected = 'Guangdong';
  contactForm: FormGroup;
  emailPattern: RegExp = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
  mobilePattern: RegExp = /^((1){1}){1}[1-9]{1}[0-9]{9}$/;
  landLinepattern:RegExp= /^\(?[0-9]{3}\)?[-]([0-9]{12})[-]([0-9]{4})$/;
  validForm: boolean = false;
  billingForm: FormGroup;
  bothvalidForms: boolean = false;
  buttonName: string;
  // billingOption: string = "";
  disableBillingShipping: boolean;
  showBillingShipping: boolean;
  isContactFormValidFlag: boolean;
  private formsChecked: boolean;
  isBillingFormValidFlag: boolean;
  showbillingOption: string = 'yes';
  showpickupOption: string = 'yes';
  showEmailField: string = 'yes';


  billingOption: string;
  billingValues: string[] = ['Yes', 'No (Please specify the reason)'];

  pickupOption: string;
  pickupValues: string[] = ['Yes', 'No'];


  taxTypeOption: string;
  taxTypeValues: string[] = ['General Tax Payer', 'Small Scale Tax Payer'];

  statementOption: string;
  statementValues: string[] = ['By Email', 'By Postal (Billing address will be used)'];





  // matcher = new MyErrorStateMatcher();
  constructor(private fb: FormBuilder, private router: Router, private baccnService: BaccnService) {


    this.contactForm = fb.group(
      {
        'titleField': [this.baccnService.detailModel.titleField, Validators.required],
        'userName': [this.baccnService.detailModel.userName, [Validators.required, Validators.minLength(2), Validators.maxLength(10)]],
        'position': [this.baccnService.detailModel.position, Validators.required],
        'email': [this.baccnService.detailModel.email, [Validators.required, Validators.pattern(this.emailPattern)]],
        'mobileNumber1': [this.baccnService.detailModel.mobileNumber1, [Validators.required, Validators.pattern(this.mobilePattern)]],
        'landLine': [this.baccnService.detailModel.landLine],
        'mobileNumber2': [this.baccnService.detailModel.mobileNumber2],


        'cNameCn': [this.baccnService.detailModel.cNameCn, [Validators.required]],
        'cNameEn': [this.baccnService.detailModel.cNameEn, [Validators.required]],
        'taxId': [this.baccnService.detailModel.taxId, Validators.required],
        'businessType': [this.baccnService.detailModel.businessType, Validators.required],
        'businessNature': [this.baccnService.detailModel.businessNature, Validators.required],
        'cmpBilling': [this.baccnService.detailModel.cmpBilling],

        'companyAdr': [this.baccnService.detailModel.companyAdr, Validators.required],
        'postCode1': [this.baccnService.detailModel.postCode1, Validators.required],
        'billingOption': [this.baccnService.detailModel.billingOption, Validators.required],
        'pickupOption': [this.baccnService.detailModel.pickupOption, Validators.required],



        'BillValForm': this.getbillvalform(0),



        'ShipValForm': this.getshipvalform(0)




        // new FormGroup({
        //   'entReason': [this.baccnService.detailModel.entReason, Validators.required]
        // })
      });

    if (!this.baccnService.detailModel.pickupOption || (this.baccnService.detailModel.pickupOption && this.baccnService.detailModel.pickupOption === 'Yes')) {
      this.contactForm.removeControl('ShipValForm');
    }
    if (!this.baccnService.detailModel.billingOption || (this.baccnService.detailModel.billingOption && this.baccnService.detailModel.billingOption === 'Yes')) {
      this.contactForm.removeControl('BillValForm');
    }
    if (baccnService.detailModel.isNotContinueRequired) {
      this.bothvalidForms = true;
    }

    this.baccnService.checkCompanyAndContactForms.subscribe((check) => {
      if (check) {
        this.validateContactForm(true);

      }
    });

    this.billingForm = fb.group({


      'bankName': [this.baccnService.detailModel.bankName, Validators.required],
      'bankNum': [this.baccnService.detailModel.bankNum, Validators.required],

      // 'emailB1': [this.baccnService.detailModel.emailB1, [Validators.required, Validators.pattern(this.emailPattern)]],
      // 'emailB2': [this.baccnService.detailModel.emailB2, [Validators.required, Validators.pattern(this.emailPattern)]],

      'needs': [this.baccnService.detailModel.needs],

      'taxTypeOption': [this.baccnService.detailModel.taxTypeOption, Validators.required],
      'statementOption': [this.baccnService.detailModel.statementOption, Validators.required],

      'shippingCheckbox': [this.baccnService.detailModel.shippingCheckbox],
      'billingCheckbox': [this.baccnService.detailModel.billingCheckbox],


      'StateValForm': this.getStateValForm(0),

    }
    );
    if (!this.baccnService.detailModel.statementOption || (this.baccnService.detailModel.statementOption && this.baccnService.detailModel.statementOption === 'By Postal (Billing address will be used)')) {
      this.contactForm.removeControl('BillValForm');
    }


    this.baccnService.checkBillingAndShippingForms.subscribe((check) => {
      if (check) {
        this.validateBillingForm(true);
      }
    });

  }
  getbillvalform(isAllow) {
    let billvalform = null
    //debugger;
    if ((this.baccnService.detailModel.billingOption && this.baccnService.detailModel.billingOption !== 'Yes') || isAllow) {
      billvalform = new FormGroup({
        'entReason': new FormControl(this.baccnService.detailModel.entReason, Validators.required),
        'billingAdr': new FormControl(this.baccnService.detailModel.billingAdr, Validators.required),
        'postCode2': new FormControl(this.baccnService.detailModel.postCode2, [Validators.required, Validators.maxLength(6)])
      })
    }

    return billvalform;
  }
  getStateValForm(isAllow) {
    let StateValForm = null
    //debugger;
    if ((this.baccnService.detailModel.statementOption && this.baccnService.detailModel.statementOption !== 'By Postal (Billing address will be used)') || isAllow) {
      StateValForm = new FormGroup({
        'emailB1': new FormControl(this.baccnService.detailModel.emailB1, [Validators.required, Validators.pattern(this.emailPattern)]),
        'emailB2': new FormControl(this.baccnService.detailModel.emailB2, Validators.pattern(this.emailPattern))
      })
    }
    return StateValForm;
  }
  getshipvalform(isAllow) {
    //debugger;
    let shipvalform = null
    if ((this.baccnService.detailModel.pickupOption && this.baccnService.detailModel.pickupOption !== 'Yes') || isAllow) {
      shipvalform = new FormGroup({
        'shipAdr': new FormControl(this.baccnService.detailModel.shipAdr, Validators.required),
        'postCode3': new FormControl(this.baccnService.detailModel.postCode3, [Validators.required, Validators.maxLength(6)])
      })
    }
    return shipvalform;
  }


  ChangestatementOption() {
    //debugger;
    if (this.billingForm.get('statementOption').value === "By Postal (Billing address will be used)") {
      this.billingForm.removeControl('StateValForm');
    }
    else {
      this.billingForm.addControl('StateValForm', this.getStateValForm(1));
    }
  }
  ChangebillingOption() {
    //debugger;
    if (this.contactForm.get('billingOption').value === 'Yes') {
      // this.contactForm.controls.BillValForm = null;
      this.contactForm.removeControl('BillValForm');
      // this.contactForm.controls.BillValForm.reset(null);
    }
    else {
      this.contactForm.addControl('BillValForm', this.getbillvalform(1));
    }
  }
  ChangepickupOption() {
    //debugger;
    if (this.contactForm.get('pickupOption').value === 'Yes') {

      this.contactForm.removeControl('ShipValForm');
      // this.contactForm.controls.ShipValForm = null;

    }
    else {
      this.contactForm.addControl('ShipValForm', this.getshipvalform(1));
    }

  }



  validateContinue() {

    //debugger;
    if (!this.contactForm.get('pickupOption').value || this.contactForm.get('pickupOption').value === 'Yes') {
      this.contactForm.removeControl('ShipValForm');
    }
    if (!this.contactForm.get('billingOption').value || this.contactForm.get('billingOption').value === 'Yes') {
      this.contactForm.removeControl('BillValForm');
    }
    if (this.contactForm.valid) {
      this.validForm = true;
      this.submitted = true;
      const cntFrm = this.validateContactForm(true);

      if (cntFrm == true)
        this.bothvalidForms = true;
      else
        this.bothvalidForms = false;

      if (!cntFrm) {
        document.getElementById('errorModal_ID').click();

      }
    }
    else {
      // this.contactForm.markAsTouched();
      // this.contactForm.touched;
      this.markFormGroupTouched(this.contactForm);
      document.getElementById('errorModal_ID').click();
    }
  }
  validBillForm: boolean = false;

  
  validateReview() {
  
    //debugger;
    if (!this.billingForm.get('statementOption').value || this.billingForm.get('statementOption').value === "By Postal (Billing address will be used)") {
      this.billingForm.removeControl('StateValForm');
    }
    if (this.contactForm.valid) { //true 
      this.submitted = true;
      this.validateContactForm(true);
      const bilFrm = this.validateBillingForm(true);
      if (!bilFrm) {

        document.getElementById('errorModal_ID').click();
      }
      if (bilFrm == true && this.contactForm) {
        this.validBillForm = true;
        console.log('bilform ', this.validBillForm = true);
        this.baccnService.detailModel.isNotContinueRequired = true;
        this.router.navigate(['/review']);
        // }else
        //   this.validBillForm = false;
        // console.log('billing ', this.validateBillingForm(true));
      }

      // Issue here
      if (!this.isBillingFormValidFlag && !this.isContactFormValidFlag) {
        this.formsChecked = false;
        this.markFormGroupTouched(this.billingForm);

        console.log('complete ', this.formsChecked = false);
        return;
      } else {

        this.formsChecked = true;

        this.baccnService.detailModel.isNotContinueRequired = true;
        this.router.navigate(['/review']);
      }
      //   if(this.billingForm.status=="INVALID"){
      //   this.validForm=false;
      // }else
      //   this.validForm=true;
      //   this.router.navigate(['/review']);
      // }
    }
    else {
      // this.contactForm.markAsTouched();
      // this.contactForm.touched;
      this.markFormGroupTouched(this.contactForm);
      document.getElementById('errorModal_ID').click();
    }



  }
  private markFormGroupTouched(formGroup: FormGroup) {
    (<any>Object).values(formGroup.controls).forEach(control => {
      control.markAsTouched();

      if (control.controls) {
        this.markFormGroupTouched(control);
      }
    });
  }
  validateContactForm(data: any) {

    // this.contactForm.get('dsf').value
    if (data === true) {
      if (this.contactForm.valid === true) {
        this.baccnService.isContactFormValid.emit(true);

        this.baccnService.detailModel.titleField = this.contactForm.get('titleField').value;
        this.baccnService.detailModel.userName = this.contactForm.get('userName').value;
        this.baccnService.detailModel.mobileNumber1 = this.contactForm.get('mobileNumber1').value;
        this.baccnService.detailModel.mobileNumber2 = this.contactForm.get('mobileNumber2').value;
        this.baccnService.detailModel.email = this.contactForm.get('email').value;
        this.baccnService.detailModel.position = this.contactForm.get('position').value;
        this.baccnService.detailModel.landLine = this.contactForm.get('landLine').value;


        this.baccnService.detailModel.cNameCn = this.contactForm.get('cNameCn').value;
        this.baccnService.detailModel.cNameEn = this.contactForm.get('cNameEn').value;
        this.baccnService.detailModel.taxId = this.contactForm.get('taxId').value;
        this.baccnService.detailModel.businessType = this.contactForm.get('businessType').value;
        this.baccnService.detailModel.businessNature = this.contactForm.get('businessNature').value;
        this.baccnService.detailModel.cmpBilling = this.contactForm.get('cmpBilling').value;
        this.baccnService.detailModel.companyAdr = this.contactForm.get('companyAdr').value;
        this.baccnService.detailModel.postCode1 = this.contactForm.get('postCode1').value;

        this.baccnService.detailModel.billingOption = this.contactForm.get('billingOption').value;
        this.baccnService.detailModel.pickupOption = this.contactForm.get('pickupOption').value;


        this.baccnService.detailModel.entReason = this.contactForm.get('BillValForm') ? this.contactForm.get('BillValForm.entReason').value : '';
        this.baccnService.detailModel.billingAdr = this.contactForm.get('BillValForm') ? this.contactForm.get('BillValForm.billingAdr').value : '';

        this.baccnService.detailModel.postCode2 = this.contactForm.get('BillValForm') ? this.contactForm.get('BillValForm.postCode2').value : null;
        this.baccnService.detailModel.shipAdr = this.contactForm.get('ShipValForm') ? this.contactForm.get('ShipValForm.shipAdr').value : '';

        this.baccnService.detailModel.postCode3 = this.contactForm.get('ShipValForm') ? this.contactForm.get('ShipValForm.postCode3').value : null;

        this.baccnService.detailModel.billingOption = this.contactForm.get('billingOption').value;
        this.baccnService.detailModel.pickupOption = this.contactForm.get('pickupOption').value;



        // this.baccnService.detailModel.radioBilYes = this.contactForm.get('radioBilYes').value;
        // this.baccnService.detailModel.radioBilNo = this.contactForm.get('radioBilNo').value;
        // this.baccnService.detailModel.radioPickYes = this.contactForm.get('radioPickYes').value;
        // this.baccnService.detailModel.radioPickNo = this.contactForm.get('radioPickNo').value;


      } else {
        this.baccnService.isContactFormValid.emit(false);
      }
    }
    return this.contactForm.valid;
  }



  validateBillingForm(data: any) {
    if (data === true) {
      if (this.billingForm.valid === true) {
        this.baccnService.isBillingFormValid.emit(true);
        this.baccnService.detailModel.bankName = this.billingForm.get('bankName').value;
        this.baccnService.detailModel.bankNum = this.billingForm.get('bankNum').value;
        // this.baccnService.detailModel.emailB1 = this.billingForm.get('emailB1').value;
        this.baccnService.detailModel.emailB1 = this.billingForm.get('StateValForm') ? this.billingForm.get('StateValForm.emailB1').value : null;
        this.baccnService.detailModel.emailB2 = this.billingForm.get('StateValForm') ? this.billingForm.get('StateValForm.emailB2').value : null;

        this.baccnService.detailModel.needs = this.billingForm.get('needs').value;

        this.baccnService.detailModel.taxTypeOption = this.billingForm.get('taxTypeOption').value;
        this.baccnService.detailModel.statementOption = this.billingForm.get('statementOption').value;
        this.baccnService.detailModel.billingCheckbox = this.billingForm.get('billingCheckbox').value;
        this.baccnService.detailModel.shippingCheckbox = this.billingForm.get('shippingCheckbox').value;

        // this.baccnService.detailModel.radioEmailNo = this.billingForm.get('radioEmailNo').value;
        // this.baccnService.detailModel.radioPostalYes = this.billingForm.get('radioPostalYes').value;



        // this.emailB1 = this.billingForm.get('emailB1').value;
      } else {
        this.baccnService.isBillingFormValid.emit(false);
      }
    }
    return this.billingForm.valid;
  }





  gotoReviews() {
    this.router.navigate(['/review']);
  }
  onSubmit() {
    if (this.contactForm.status == "VALID")
      this.validForm = true;
    this.router.navigate(['/review']);
  }
  ngOnInit() {
    this.showhide = false;
  }

  natureofBusiness: boolean = false;
  natureOther() {
    this.natureofBusiness = true;
  }











  //Help text
  hlpMob1: boolean = false;
  hlpMob2: boolean = false;
  hlpTax: boolean = false;
  hlpbType: boolean = false;
  hlpbNature: boolean = false;
  hlpcCity: boolean = false;
  hlpbCity: boolean = false;
  hlppCity: boolean = false;
  hlptTax: boolean = false;
  hlpsNeed: boolean = false;
  enableHelptext(helptext: string) {
    if (helptext == 'hlpMob1') {
      this.hlpMob1 = !this.hlpMob1;
    } else if (helptext == 'hlpMob2') {
      this.hlpMob2 = !this.hlpMob2;
    } else if (helptext == 'hlpTax') {
      this.hlpTax = !this.hlpTax;
    } else if (helptext == 'hlpbType') {
      this.hlpbType = !this.hlpbType;
    } else if (helptext == 'hlpbNature') {
      this.hlpbNature = !this.hlpbNature;
    } else if (helptext == 'hlpcCity') {
      this.hlpcCity = !this.hlpcCity;
    } else if (helptext == 'hlpbCity') {
      this.hlpbCity = !this.hlpbCity;
    } else if (helptext == 'hlppCity') {
      this.hlppCity = !this.hlppCity;
    } else if (helptext == 'hlptTax') {
      this.hlptTax = !this.hlptTax;
    } else if (helptext == 'hlpsNeed') {
      this.hlpsNeed = !this.hlpsNeed;
    }
  }


}
